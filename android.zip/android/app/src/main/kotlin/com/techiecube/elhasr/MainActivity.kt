package com.techiecube.elhasr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
